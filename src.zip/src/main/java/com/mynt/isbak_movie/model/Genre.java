package com.mynt.isbak_movie.model;

public enum Genre {

    ACTION,
    COMEDY,
    ROMANCE,
    HORROR,
    FANTASY;
    
}
