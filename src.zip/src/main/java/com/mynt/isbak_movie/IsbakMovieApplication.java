package com.mynt.isbak_movie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IsbakMovieApplication {

	public static void main(String[] args) {
		SpringApplication.run(IsbakMovieApplication.class, args);
	}

}
