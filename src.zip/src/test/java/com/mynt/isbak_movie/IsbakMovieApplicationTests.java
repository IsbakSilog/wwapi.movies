package com.mynt.isbak_movie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IsbakMovieApplicationTests {

	@Test
	void contextLoads() {
	}

}
